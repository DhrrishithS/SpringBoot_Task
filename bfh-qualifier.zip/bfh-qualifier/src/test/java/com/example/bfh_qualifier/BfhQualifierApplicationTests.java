package com.example.bfh_qualifier;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BfhQualifierApplicationTests {

	@Test
	void contextLoads() {
	}

}
