package com.example.bfh_qualifier;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class TestRunner implements CommandLineRunner {
    @Override
    public void run(String... args) {
        System.out.println(">>> TestRunner: Spring Boot started and component scanning works!");
    }
}
