package com.example.bfh_qualifier;

import org.springframework.stereotype.Component;

@Component
public class SQLSolver {

    public int extractLastTwoDigits(String regNo) {
        if (regNo == null) return -1;
        String digits = regNo.replaceAll("\\D+", "");
        if (digits.length() == 0) return -1;
        if (digits.length() == 1) return Integer.parseInt(digits);
        return Integer.parseInt(digits.substring(digits.length() - 2));
    }

    public String getFinalQuery(int lastTwo) {
        if (lastTwo % 2 == 1) {
            return "/* SQL for Question 1 */";
        } else {
            return """
WITH high_paid AS (
  SELECT DISTINCT e.emp_id,
         e.first_name,
         e.last_name,
         e.department AS department_id,
         TIMESTAMPDIFF(YEAR, e.dob, CURDATE()) AS age
  FROM employee e
  JOIN payments p ON e.emp_id = p.emp_id
  WHERE p.amount > 70000
),
ranked AS (
  SELECT hp.*,
         ROW_NUMBER() OVER (PARTITION BY hp.department_id ORDER BY hp.emp_id) AS rn
  FROM high_paid hp
),
emp_list_per_dept AS (
  SELECT department_id,
         GROUP_CONCAT(CONCAT(first_name, ' ', last_name) ORDER BY emp_id SEPARATOR ', ') AS employee_list
  FROM ranked
  WHERE rn <= 10
  GROUP BY department_id
),
avg_age_per_dept AS (
  SELECT department_id, ROUND(AVG(age), 2) AS average_age
  FROM high_paid
  GROUP BY department_id
)
SELECT d.department_name AS DEPARTMENT_NAME,
       a.average_age AS AVERAGE_AGE,
       COALESCE(e.employee_list, '') AS EMPLOYEE_LIST
FROM department d
LEFT JOIN avg_age_per_dept a ON d.department_id = a.department_id
LEFT JOIN emp_list_per_dept e ON d.department_id = e.department_id
ORDER BY d.department_id DESC;
""";

        }
    }
}
