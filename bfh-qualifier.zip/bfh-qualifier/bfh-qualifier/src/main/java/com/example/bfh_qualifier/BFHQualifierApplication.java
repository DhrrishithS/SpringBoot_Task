package com.example.bfh_qualifier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BFHQualifierApplication {
    public static void main(String[] args) {
        System.out.println(">>> BFHQualifierApplication starting (main entered)");
        SpringApplication.run(BFHQualifierApplication.class, args);
        System.out.println(">>> SpringApplication.run returned (app may have stopped)");
    }
}
